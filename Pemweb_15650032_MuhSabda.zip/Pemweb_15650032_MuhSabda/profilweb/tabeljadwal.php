<DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>JADWALKULIAH</title>
</head>
<body>


<?php
echo "<br>";
echo "JADWAL KULIAH";
echo "<br>";

?>
<?php
echo "<br>";
echo "<table width = 500 border =5>
<tr bgcolor=00fffff>
<td>SENIN</td>
<td>SELASA</td>
<td>RABU</td>
</tr>
<tr>
<td>PCD</td>
<td>Sistem Operasi</td>
<td>APS</td>
</tr>
<tr>
<td>Sistem Operasi</td>
<td>Sistem Operasi</td>
<td>Fiqih</td>
</tr>
<tr>
<td>PemWeb</td>
<td>-</td>
<td>-</td>
</tr>
<tr bgcolor=00fffff>
<td>KAMIS</td>
<td>JUM'AT</td>
<td>SABTU</td>
</tr>
<tr>
<td>Bahasa Query Terstruktur</td>
<td>PemWeb</td>
<td>-</td>
</tr>
<tr>
<td>-</td>
<td>PemWeb</td>
<td>-</td>
</tr>
<tr>
<td>-</td>
<td>-</td>
<td>-</td>
</tr>
</table>";

?>
<p><strong><a href="index.html">Beranda</a></strong></p>
</body>
</html>
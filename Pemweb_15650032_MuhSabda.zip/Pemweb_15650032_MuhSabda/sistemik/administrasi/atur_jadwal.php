<table width="338" height="207" border="0" align="center">
  <tr>
    <td width="123">Hari</td>
    <td width="6">:</td>
    <td width="195">&nbsp;</td>
  </tr>
  <tr>
    <td>Mata Pelajaran </td>
    <td>:</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Jam ke </td>
    <td>:</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Kelas</td>
    <td>:</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Guru Pengajar </td>
    <td>:</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>

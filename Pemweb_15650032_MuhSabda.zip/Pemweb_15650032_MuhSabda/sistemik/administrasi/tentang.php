<div align="center">
<br />
<p><img src="icon/sekedar-tutorial.png" /></p>
<p><a href="http://sekedar-tutorial.blogspot.com">http://sekedar-tutorial.blogspot.com</a></p>
</div>

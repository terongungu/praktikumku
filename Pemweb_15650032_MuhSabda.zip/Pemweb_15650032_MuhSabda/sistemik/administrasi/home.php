<?php
include "../include/session_admin.php";
?>

	<div align="center">
	<h2><a href="#">Selamat Datang di Sistem Informasi Akademik Sekolah</a></h2>
	<p><?php echo date("H:m:s, d F Y") ?></p>
	<p>Anda sedang berada di halaman administrator Sistem Informasi Akademik Sekolah.</p><br />
	<p> <img src="../admin/images/logo.gif"></p>
	</div>
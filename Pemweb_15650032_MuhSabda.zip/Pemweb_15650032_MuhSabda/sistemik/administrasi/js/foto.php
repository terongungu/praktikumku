<link rel="stylesheet" href="style.css" />

<script type="text/javascript" src="tinybox.js"></script>
<li onclick="TINY.box.show({image:'images/rhino.jpg',boxid:'frameless',animate:true,openjs:function(){openJS()}})">Image, Load Callback</li>

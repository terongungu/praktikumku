<div class="post">
	<h2 class="title"><a href="#">Halaman Profil</a></h2>
	<p class="meta"><em>Sunday, April 26, 2009 7:27 AM Posted by <a href="#">Someone</a></em></p>
	<div class="entry">
		<p>Ini isi halaman <strong>Profil</strong>, silahkan diganti isi nya. </p>
		<div><a href="#" class="links">Full Story</a></div>
	</div>
</div>

